******CSharp Assignment******
1. Conversions
2. Equality Operations
3. Prime Numbers
4. Equipment Inventory(task 6 included)
5. Duck(task 7 included)
6. Priority Queue1
7. Priority Queue2
8. Priority Queue3
9. Extensions
10. Delegates
11. Extensions on IEnumerable Methods
12. Product-Inventory
13. Observable Collections
14. File Operations
15. Exception Handling
[0 to exit]