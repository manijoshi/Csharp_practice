﻿namespace PriorityQueue2
{
    internal interface IEquatable
    {
    }
}