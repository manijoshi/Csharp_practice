﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DuckGameBusinessLayer
{
    public interface QuackBehavior
    {
        public string Quack();
    }
}
