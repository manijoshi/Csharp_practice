﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DuckGameBusinessLayer
{
    class FlySlow : FlyBehavior
    {
        public string Fly()
        {
            return "I fly slow!!!";
        }
    }
}
