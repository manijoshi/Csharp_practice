﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DuckGameBusinessLayer
{
    class Squeak : QuackBehavior
    {
        public string Quack()
        {
            return "I can Squeak!!!";
        }
    }
}
