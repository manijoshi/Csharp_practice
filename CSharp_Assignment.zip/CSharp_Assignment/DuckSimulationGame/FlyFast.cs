﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DuckGameBusinessLayer
{
    public class FlyFast : FlyBehavior
    {
        public string Fly()
        {
            return "I can fly fast!!!";
        }
    }
}
