﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DuckGameBusinessLayer
{
    class QuackLoud : QuackBehavior
    {
        public string Quack()
        {
            return "I can quack!!";
        }
    }
}
